from machine import I2C, Pin, SPI, UART
import time
from ST7735 import TFT
from sysfont import sysfont

# --- SPI0 for TFT ---
spi = SPI(0, baudrate=20000000, polarity=0, phase=0,
          sck=Pin(18), mosi=Pin(19), miso=None)
tft = TFT(spi, 21, 20, 22)
tft.rgb(True)
tft.init_7735(tft.GREENTAB80x160)

# --- I2C1 (not used now, reserved for future sensors) ---
# i2c = I2C(1, sda=Pin(2), scl=Pin(3), freq=100_000)

# --- UART0 for RX (from PC) ---
uart = UART(0, baudrate=9600, tx=Pin(0), rx=Pin(1))

# --- LED on GPIO27 ---
led = Pin(27, Pin.OUT)
led.value(0)  # Start OFF

# --- Intro Screen ---

tft.fill(TFT.BLACK)
tft.text((0, 0), "RP2040", TFT.RED, sysfont, 2)
tft.text((0, 20), "UART TEST", TFT.RED, sysfont, 2)
tft.text((0, 40), "Ceyhun Pempeci", TFT.BLUE, sysfont, 2)
tft.text((0, 65), "2025", TFT.GREEN, sysfont, 2)
time.sleep(5)

# --- Main Loop ---
buffer = b""
while True:
    if uart.any():
        char = uart.read(1)
        if char == b'\n':  # End of line
            msg = buffer.decode().strip().upper()
            buffer = b""

            # Show received message on LCD
            tft.fill(TFT.BLACK)
            tft.text((0, 20), "RECEIVED:", TFT.YELLOW, sysfont, 2)
            tft.text((0, 40), msg, TFT.GREEN, sysfont, 2)

            # Handle LED control
            if msg == "LED ON":
                led.value(1)
            elif msg == "LED OFF":
                led.value(0)
        else:
            buffer += char

    time.sleep(0.01)